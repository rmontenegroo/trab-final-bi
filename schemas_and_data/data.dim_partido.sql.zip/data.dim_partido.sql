--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Debian 13.1-1.pgdg100+1)
-- Dumped by pg_dump version 13.1 (Debian 13.1-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: dim_partido; Type: TABLE DATA; Schema: dw; Owner: -
--

INSERT INTO "public".dim_partido VALUES (1, 1, 'ARENA');
INSERT INTO "public".dim_partido VALUES (2, 2, 'AVANTE');
INSERT INTO "public".dim_partido VALUES (3, 3, 'CIDADANIA');
INSERT INTO "public".dim_partido VALUES (4, 4, 'DEMOCRATAS');
INSERT INTO "public".dim_partido VALUES (5, 5, 'N/A');
INSERT INTO "public".dim_partido VALUES (6, 6, 'NOVO');
INSERT INTO "public".dim_partido VALUES (7, 7, 'PATRIOTA');
INSERT INTO "public".dim_partido VALUES (8, 8, 'PCdoB');
INSERT INTO "public".dim_partido VALUES (9, 9, 'PDS');
INSERT INTO "public".dim_partido VALUES (10, 10, 'PDT');
INSERT INTO "public".dim_partido VALUES (11, 11, 'PEN');
INSERT INTO "public".dim_partido VALUES (12, 12, 'PFL');
INSERT INTO "public".dim_partido VALUES (13, 13, 'PHS');
INSERT INTO "public".dim_partido VALUES (14, 14, 'PL');
INSERT INTO "public".dim_partido VALUES (15, 15, 'PMDB');
INSERT INTO "public".dim_partido VALUES (16, 16, 'PMN');
INSERT INTO "public".dim_partido VALUES (17, 17, 'PODEMOS');
INSERT INTO "public".dim_partido VALUES (18, 18, 'PP');
INSERT INTO "public".dim_partido VALUES (19, 19, 'PPS');
INSERT INTO "public".dim_partido VALUES (20, 20, 'PR');
INSERT INTO "public".dim_partido VALUES (21, 21, 'PRB');
INSERT INTO "public".dim_partido VALUES (22, 22, 'PROGRESSISTAS');
INSERT INTO "public".dim_partido VALUES (23, 23, 'PROS');
INSERT INTO "public".dim_partido VALUES (24, 24, 'PRP');
INSERT INTO "public".dim_partido VALUES (25, 25, 'PRTB');
INSERT INTO "public".dim_partido VALUES (26, 26, 'PSB');
INSERT INTO "public".dim_partido VALUES (27, 27, 'PSC');
INSERT INTO "public".dim_partido VALUES (28, 28, 'PSD');
INSERT INTO "public".dim_partido VALUES (29, 29, 'PSDB');
INSERT INTO "public".dim_partido VALUES (30, 30, 'PSDC');
INSERT INTO "public".dim_partido VALUES (31, 31, 'PSL');
INSERT INTO "public".dim_partido VALUES (32, 32, 'PSOL');
INSERT INTO "public".dim_partido VALUES (33, 33, 'PT');
INSERT INTO "public".dim_partido VALUES (34, 34, 'PTB');
INSERT INTO "public".dim_partido VALUES (35, 35, 'PTC');
INSERT INTO "public".dim_partido VALUES (36, 36, 'PTdoB');
INSERT INTO "public".dim_partido VALUES (37, 37, 'PTN');
INSERT INTO "public".dim_partido VALUES (38, 38, 'PV');
INSERT INTO "public".dim_partido VALUES (39, 39, 'REDE');
INSERT INTO "public".dim_partido VALUES (40, 40, 'REPUBLICANOS');
INSERT INTO "public".dim_partido VALUES (41, 41, 'SEM PARTIDO');
INSERT INTO "public".dim_partido VALUES (42, 42, 'SOLIDARIEDADE');
INSERT INTO "public".dim_partido VALUES (43, 43, 'UDN');

