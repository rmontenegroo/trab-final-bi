--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2 (Debian 13.2-1.pgdg100+1)
-- Dumped by pg_dump version 13.2 (Debian 13.2-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: dim_partido; Type: TABLE DATA; Schema: dw; Owner: postgres
--

INSERT INTO dw.dim_partido VALUES (1, 1, 'ARENA');
INSERT INTO dw.dim_partido VALUES (2, 2, 'AVANTE');
INSERT INTO dw.dim_partido VALUES (3, 3, 'CIDADANIA');
INSERT INTO dw.dim_partido VALUES (4, 4, 'DEMOCRATAS');
INSERT INTO dw.dim_partido VALUES (5, 5, 'N/A');
INSERT INTO dw.dim_partido VALUES (6, 6, 'NOVO');
INSERT INTO dw.dim_partido VALUES (7, 7, 'PATRIOTA');
INSERT INTO dw.dim_partido VALUES (8, 8, 'PCdoB');
INSERT INTO dw.dim_partido VALUES (9, 9, 'PDS');
INSERT INTO dw.dim_partido VALUES (10, 10, 'PDT');
INSERT INTO dw.dim_partido VALUES (11, 11, 'PEN');
INSERT INTO dw.dim_partido VALUES (12, 12, 'PFL');
INSERT INTO dw.dim_partido VALUES (13, 13, 'PHS');
INSERT INTO dw.dim_partido VALUES (14, 14, 'PL');
INSERT INTO dw.dim_partido VALUES (15, 15, 'PMDB');
INSERT INTO dw.dim_partido VALUES (16, 16, 'PMN');
INSERT INTO dw.dim_partido VALUES (17, 17, 'PODEMOS');
INSERT INTO dw.dim_partido VALUES (18, 18, 'PP');
INSERT INTO dw.dim_partido VALUES (19, 19, 'PPS');
INSERT INTO dw.dim_partido VALUES (20, 20, 'PR');
INSERT INTO dw.dim_partido VALUES (21, 21, 'PRB');
INSERT INTO dw.dim_partido VALUES (22, 22, 'PROGRESSISTAS');
INSERT INTO dw.dim_partido VALUES (23, 23, 'PROS');
INSERT INTO dw.dim_partido VALUES (24, 24, 'PRP');
INSERT INTO dw.dim_partido VALUES (25, 25, 'PRTB');
INSERT INTO dw.dim_partido VALUES (26, 26, 'PSB');
INSERT INTO dw.dim_partido VALUES (27, 27, 'PSC');
INSERT INTO dw.dim_partido VALUES (28, 28, 'PSD');
INSERT INTO dw.dim_partido VALUES (29, 29, 'PSDB');
INSERT INTO dw.dim_partido VALUES (30, 30, 'PSDC');
INSERT INTO dw.dim_partido VALUES (31, 31, 'PSL');
INSERT INTO dw.dim_partido VALUES (32, 32, 'PSOL');
INSERT INTO dw.dim_partido VALUES (33, 33, 'PT');
INSERT INTO dw.dim_partido VALUES (34, 34, 'PTB');
INSERT INTO dw.dim_partido VALUES (35, 35, 'PTC');
INSERT INTO dw.dim_partido VALUES (36, 36, 'PTdoB');
INSERT INTO dw.dim_partido VALUES (37, 37, 'PTN');
INSERT INTO dw.dim_partido VALUES (38, 38, 'PV');
INSERT INTO dw.dim_partido VALUES (39, 39, 'REDE');
INSERT INTO dw.dim_partido VALUES (40, 40, 'REPUBLICANOS');
INSERT INTO dw.dim_partido VALUES (41, 41, 'SEM PARTIDO');
INSERT INTO dw.dim_partido VALUES (42, 42, 'SOLIDARIEDADE');
INSERT INTO dw.dim_partido VALUES (43, 43, 'UDN');


--
-- Name: dim_partido_sk_partido_seq; Type: SEQUENCE SET; Schema: dw; Owner: postgres
--

SELECT pg_catalog.setval('dw.dim_partido_sk_partido_seq', 1, false);


--
-- PostgreSQL database dump complete
--

